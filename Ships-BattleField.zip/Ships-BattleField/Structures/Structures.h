#ifndef STRUCTURES_H
#define STRUCTURES_H

#include "Line/Line.cc"
#include "Points/Point2D.cc"

#endif