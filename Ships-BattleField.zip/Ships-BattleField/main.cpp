#include "Console/Console.cc"
#include "Game/Game.cc"
#include "WinMenu/DataMenu.cc"

int main()
{
    Console newWindow;
    newWindow.setConsoleSize();

    Game newGame(newWindow);

    newGame.play();

    // Message newMessage(newWindow.getScreenHandle());

    // newMessage.showMessage(6);
    Console::staticSleep(500000);

}