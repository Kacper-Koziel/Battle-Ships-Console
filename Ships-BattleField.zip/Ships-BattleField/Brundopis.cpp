#include <iostream>

struct Point
{
    private:
    int x;

    public:
    Point(int x) : x(x) {}
    int& getX() { return this->x;};
};


int main()
{
    Point newP(2);

    std::cout << newP.getX();

    std::cin >> newP.getX();

    std::cout << newP.getX();
}