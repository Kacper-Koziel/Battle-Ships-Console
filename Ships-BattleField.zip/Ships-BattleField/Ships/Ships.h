#ifndef SHIPS_H
#define SHIPS_H

#include "Single/Single.cc"
#include "Dual/Dual.cc"
#include "Tripple/Tripple.cc"
#include "Quadra/Quadra.cc"
#include "Base/Base.h"

#endif