#pragma once

#include "Player.h"

Player::Player(Board &myBoard, int id) : myBoard(myBoard), id(id) {}

Player::~Player()
{
    
}
